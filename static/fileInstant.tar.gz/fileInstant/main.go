package main

import (
	_ "fileInstant/routers"
	"fmt"
	"os"
	"strconv"
	"syscall"
	"time"

	"github.com/astaxie/beego"
	"github.com/astaxie/beego/toolbox"
	"github.com/go-redis/redis"
)

func timespecToTime(ts syscall.Timespec) time.Time {
	return time.Unix(int64(ts.Sec), int64(ts.Nsec))
}

func init() {
	tk := toolbox.NewTask("myTask", "* * * * * *", func() error {
		finfo, _ := os.Stat("./tests")
		// Sys()返回的是interface{}，所以需要类型断言，不同平台需要的类型不一样，linux上为*syscall.Stat_t
		statt := finfo.Sys().(*syscall.Stat_t)
		fmt.Println(statt.Mtim.Sec)
		client := redis.NewClient(&redis.Options{
			Addr:     "127.0.0.1:6379",
			Password: "", // no password set
			DB:       0,  // use default DB
		})
		// err := client.Set("lasttime", strconv.FormatInt(statt.Mtim.Sec, 10), 0).Err()
		// if err != nil {
		// 	panic(err)
		// }
		val, err := client.Get("lasttime").Result()
		if err != nil {
			panic(err)
		}
		fmt.Println("lasttime", val)
		if val != strconv.FormatInt(statt.Mtim.Sec, 10) {
			err = client.Set("lasttime", strconv.FormatInt(statt.Mtim.Sec, 10), 0).Err()
			if err != nil {
				panic(err)
			}
			//时间有变，准备同步文件
			fmt.Println("Start Sync File")
		}
		return nil
	})
	err := tk.Run()
	if err != nil {
		fmt.Println(err)
	}
	toolbox.AddTask("myTask", tk)
	toolbox.StartTask()
	//defer toolbox.StopTask()
}

func main() {
	beego.Run()
}
